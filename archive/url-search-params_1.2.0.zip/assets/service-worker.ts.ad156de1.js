(function main() {
  chrome.runtime.onInstalled.addListener(() => {
    chrome.contextMenus.create({
      id: "URL Search Params",
      title: "URL Search Params",
      contexts: ["link", "page"]
    });
  });
  chrome.contextMenus.onClicked.addListener((info, tab) => {
    const target = info.linkUrl || info.pageUrl;
    const windowId = ((tab == null ? void 0 : tab.windowId) || "") + "";
    const params = new URLSearchParams({ target, windowId }).toString();
    const url = "./pages/popup.html?" + params;
    chrome.windows.create({
      focused: true,
      height: 500,
      width: 500,
      type: "popup",
      url
    });
  });
})();
